﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NewBehaviourScript : MonoBehaviour
{
    int score = 0;
    int high_score = 0;
    int streak = 0;
    int food;//red - 1 , blue - 2
    int Nodecounter = 2;
    public bool colRight;
    public bool colleft;
    public bool colforward;
    public bool colback;

    public TextMesh text;
    public GameObject head;
    public GameObject node;
    public GameObject tail;
    public GameObject redfood;
    public GameObject bluefood;
    List<GameObject> nodes;
    

    private void Start()
    {
        foodinit();
        nodes = new List<GameObject>();
        nodes.Add(head);
        nodes.Add(node);

    }
    void Awake()
    {
        QualitySettings.vSyncCount = 0;  // VSync must be disabled
        Application.targetFrameRate = 10;

    }


    public void tailinit()
    {
        Vector3 position = nodes[Nodecounter - 1].transform.position;
        nodes.Add((GameObject)Instantiate(tail, position, Quaternion.identity));
        Nodecounter++;
    }

    public void foodinit()
    {
        Vector3 position = new Vector3(Random.Range(-98.0f, 98.0f), 7, Random.Range(-73.0f, 73.0f));
        if (Random.Range(1f, 100f) >= 50)
        {
            Instantiate(redfood, position, Quaternion.identity);
        }
        else
        {
            Instantiate(bluefood, position, Quaternion.identity);
        }
    }

    // Start is called before the first frame update
    private void OnCollisionEnter(Collision collision)
    {

        if (collision.gameObject.tag == "red food")
        {
            if (food == 1)
            {
                score = score + ((++streak) * 15);
            }
            else
            {
                score = score + 15;
                food = 1;
                streak = 1;
            }

        }


        if (collision.gameObject.tag == "blue food")
        {
            if (food == 2)
            {
                score = score + ((++streak) * 20);
            }
            else
            {
                score = score + 20;
                food = 2;
                streak = 1;
            }
        }
        if (collision.gameObject.tag != "Player" && collision.gameObject.tag != "WALLS")
        {
            Destroy(collision.gameObject);
            foodinit();
            tailinit();
        }

    }







    private int[] direction = { 0, 1, 2, 3 };//  {up , right , down , left}
    private int dir = 0;

    public void FixedUpdate()
    {
        colRight = Physics.Raycast(transform.position, Vector3.right, 6.0f);
        colleft = Physics.Raycast(transform.position, Vector3.left, 6.0f);
        colforward = Physics.Raycast(transform.position, Vector3.forward, 6.0f);
        colback = Physics.Raycast(transform.position, Vector3.back, 6.0f);
    }

    private void Update()
    {
        ////////game over case:
        if (colRight && dir == 1)
        {
            // SceneManager.LoadScene(2);
        }

            if (colleft && dir == 3)
            {
               // SceneManager.LoadScene(2);
            }

            if (colforward && dir == 0)
            {
               // SceneManager.LoadScene(2);
            }

            if (colback && dir == 2)
            {
                //SceneManager.LoadScene(2);
            }
            //////////////////////////////////////////////////
            ////// move player wrt keys
            if (!colRight)
            {
                if (Input.GetKeyDown(KeyCode.RightArrow) && dir != 3)
                {
                    Vector3 position = nodes[Nodecounter - 1].transform.position;
                    position.x = position.x + 4;
                    position.y = 5f;
                    //nodes.transform.position = head.transform.position;
                    // head.transform.position = position;
                    for (int i = Nodecounter - 1; i >= 1; i--)
                    {
                        nodes[i].transform.position = nodes[i - 1].transform.position;
                    }
                    nodes[1].transform.position = nodes[0].transform.position;
                    nodes[0].transform.position = position;
                    dir = 1;

                }
            }

            if (!colleft)
            {
                if (Input.GetKeyDown(KeyCode.LeftArrow) && dir != 1)
                {
                    Vector3 position = head.transform.position;
                    position.x = position.x - 4;
                    position.y = 5f;
                    for (int i = Nodecounter - 1; i >= 1; i--)
                    {
                        nodes[i].transform.position = nodes[i - 1].transform.position;
                    }
                    nodes[1].transform.position = nodes[0].transform.position;
                    nodes[0].transform.position = position;
                    dir = 3;

                }
            }

            if (!colforward)
            {
                if (Input.GetKeyDown(KeyCode.UpArrow) && dir != 2)
                {
                    Vector3 position = head.transform.position;
                    position.z = position.z + 4;
                    position.y = 5f;
                    for (int i = Nodecounter - 1; i >= 1; i--)
                    {
                        nodes[i].transform.position = nodes[i - 1].transform.position;
                    }
                    nodes[1].transform.position = nodes[0].transform.position;
                    nodes[0].transform.position = position;
                    dir = 0;

                }
            }

            if (Input.GetKeyDown(KeyCode.DownArrow) && dir != 0)
            {
                Vector3 position = head.transform.position;
                position.z = position.z - 4;
                position.y = 5f;
                for (int i = Nodecounter - 1; i >= 1; i--)
                {
                    nodes[i].transform.position = nodes[i - 1].transform.position;
                }
                nodes[1].transform.position = nodes[0].transform.position;
                nodes[0].transform.position = position;
                dir = 2;

            }
            ///////////////////////////////////////////////////
            ///move auto
            ///

            if (dir == 0)
            {
                Vector3 position = nodes[0].transform.position;
                position.z = position.z + 4;
                position.y = 5f;
                for (int i = Nodecounter - 1; i >= 1; i--)
                {
                    nodes[i].transform.position = nodes[i - 1].transform.position;
                }
                nodes[1].transform.position = nodes[0].transform.position;
                nodes[0].transform.position = position;
                dir = 0;
            }
            if (dir == 1)
            {
                Vector3 position = nodes[0].transform.position;
                position.x = position.x + 4;
                position.y = 5f;
                for (int i = Nodecounter - 1; i >= 1; i--)
                {
                    nodes[i].transform.position = nodes[i - 1].transform.position;
                }
                nodes[1].transform.position = nodes[0].transform.position;
                nodes[0].transform.position = position;
                dir = 1;
            }
            if (dir == 2)
            {
                Vector3 position = nodes[0].transform.position;
                position.z = position.z - 4;
                position.y = 5f;
                for (int i = Nodecounter - 1; i >= 1; i--)
                {
                    nodes[i].transform.position = nodes[i - 1].transform.position;
                }
                nodes[1].transform.position = nodes[0].transform.position;
                nodes[0].transform.position = position;
                dir = 2;
            }
            if (dir == 3)
            {
                Vector3 position = nodes[0].transform.position;
                position.x = position.x - 4;
                position.y = 5f;
                for (int i = Nodecounter - 1; i >= 1; i--)
                {
                    nodes[i].transform.position = nodes[i - 1].transform.position;
                }
                nodes[1].transform.position = nodes[0].transform.position;
                nodes[0].transform.position = position;
                dir = 3;
            }
        
    }
}
